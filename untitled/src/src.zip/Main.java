public class Main {
    public static void main(String[] args) {

        Endereco enderecoRestaurante = new Endereco(1, "Rua A", 123, "Centro", "Cidade", "Estado", "12345-678", "Complemento");

        Restaurante restaurante = new Restaurante(1, "Restaurante Buiq", enderecoRestaurante, "123456789", "Fast Food", "10:00 - 22:00", true);

        Promo promo = new Promo(1, "Promoção de Verão", "VERAO2024", 100.0, 10.0);

        Pedido pedido = new Pedido(1, "2024-11-03", restaurante, 100.50, promo, new StatusEntrega(1, "Entregue"), new FormaPagamento(1, "Cartão"), "Sem observações", 0.0, enderecoRestaurante);

        Produto produto1 = new Produto(1, "Hamburguer", "Hamburguer com bacon", 25.0, new Categoria(1, "Lanche", "Lanches rápidos"), restaurante);
        Produto produto2 = new Produto(2, "Refrigerante", "Refrigerante lata", 5.0, new Categoria(2, "Bebida", "Bebidas não alcoólicas"), restaurante);

        PedidoProduto pedidoProduto1 = new PedidoProduto(pedido, produto1, 2);
        PedidoProduto pedidoProduto2 = new PedidoProduto(pedido, produto2, 3);


        pedido.addProduto(pedidoProduto1);
        pedido.addProduto(pedidoProduto2);

        Acompanhamento acompanhamento1 = new Acompanhamento(1, "Batata frita", "Porção de batata frita", 10.0);
        Acompanhamento acompanhamento2 = new Acompanhamento(2, "Molho extra", "Molho barbecue", 2.0);

        pedido.addAcompanhamento(acompanhamento1);
        pedido.addAcompanhamento(acompanhamento2);

        System.out.println("Pedido #" + pedido.getId() + " para o Restaurante: " + restaurante.getNome());
        System.out.println("Data: " + pedido.getData());
        System.out.println("Produtos:");

        for (PedidoProduto pp : pedido.getProdutos()) {
            System.out.println(" - " + pp.getProduto().getNome() + " (Quantidade: " + pp.getQuantidade() + ")");
        }

        System.out.println("Acompanhamentos:");
        for (Acompanhamento a : pedido.getAcompanhamentos()) {
            System.out.println(" - " + a.getNome() + " (Valor: " + a.getValor() + ")");
        }

        System.out.println("Valor total: R$" + pedido.getValor());

        System.out.println("Pagamento realizado com sucesso!");
    }
}
